<?php

namespace Hdweb\Insurance\Block\Adminhtml;

use Magento\Framework\View\Element\Template\Context;
use Hdweb\Insurance\Model\InsuranceFactory;
use Magento\Cms\Model\Template\FilterProvider;

class InsuranceView extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Insurance
     */
    protected $_insurance;
    public function __construct(
        Context $context,
        InsuranceFactory $insurance,
        FilterProvider $filterProvider
    ) {
        $this->_insurance = $insurance;
        $this->_filterProvider = $filterProvider;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Hdweb Insurance Module View Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $insurance = $this->_insurance->create();
        $singleData = $insurance->load($id);
        if($singleData->getInsuranceId() || $singleData['insurance_id'] && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}
