<?php
namespace Hdweb\Tyrefinder\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const WHEEL_SEARCH_APIKEY = '12854ab0cb86796076a785e068bcd37b'; //Wheel Size API KEY
    protected $_storeManager;
    protected $_scopeConfig;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->_storeManager = $storeManager;
        $this->_scopeConfig  = $scopeConfig;
        parent::__construct($context);
    }

    public function getBaseUrl()
    {
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        return $baseUrl;
    }

    public function getStorepickupUrl()
    {
        $baseUrl = $this->getBaseUrl() . 'storepickup?ref=cart';
        return $baseUrl;
    }

    public function redirectCartToStorepickup()
    {
        $cartToStorepickup = $this->scopeConfig->getValue('carttostorepickup/general/enable', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $cartToStorepickup;
    }
}
