<?php

namespace Hdweb\Tyrefinder\Model;

use Magento\Framework\Model\AbstractModel;

class Installerbrandrim extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Hdweb\Tyrefinder\Model\ResourceModel\Installerbrandrim');
    }
}
