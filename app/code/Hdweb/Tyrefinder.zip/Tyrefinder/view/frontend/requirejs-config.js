var config = {
    map: {
        '*': {
            tyrefinder:'Hdweb_Tyrefinder/js/tyrefinder'
        }
    }
};
