// required for fix issue arrays
var config = {
    shim: {
        'Mirasvit_Sorting/js/criterion/form/conditions': {
            deps: ['prototype']
        }
    }
};
