define([
    'jquery',
    'underscore',
    'Magento_Ui/js/form/form',
    'uiRegistry'
], function ($, _, Form, Registry) {
    return Form.extend({
        defaults: {
        
        },
        
        initialize: function () {
            this._super();
          
        },
        
    });
});