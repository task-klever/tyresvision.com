<?php

namespace PayTabs\PayPage\Block;

use Magento\Framework\View\Element\Template;

/**
 * Class Pay
 */
class Pay extends Template
{
}
