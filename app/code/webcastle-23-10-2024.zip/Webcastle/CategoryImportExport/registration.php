<?php
/**
 * Webcastle_CategoryImportExport
 *
 * @category   Webcastle
 * @package    Webcastle_CategoryImportExport
 * @author     Webcastle Media
 * @copyright  2023
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Webcastle_CategoryImportExport',
    __DIR__
);
