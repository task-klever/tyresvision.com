<?php

namespace MaxMind\Exception;

class IpAddressNotFoundException extends InvalidRequestException
{
}
